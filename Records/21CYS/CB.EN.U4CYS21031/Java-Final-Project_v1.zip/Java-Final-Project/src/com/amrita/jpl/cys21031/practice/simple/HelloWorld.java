package com.amrita.jpl.cys21031.practice.simple;

/**
 * @author Kishanth K
 * @version 0.5
 *
 * A Basic Java program to print some text.
 */
public class HelloWorld {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        welcome();
    }

    public static void welcome(){
        System.out.println("I m Kishanth K");
    }
}
