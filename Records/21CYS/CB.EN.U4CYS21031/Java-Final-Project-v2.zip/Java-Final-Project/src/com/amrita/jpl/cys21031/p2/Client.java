package com.amrita.jpl.cys21031.p2;

/**
 * @author Kishanth K
 * @version 1.0
 */
interface QuizGameListener {
    void onQuestionAsked(String question);
    void onAnswerEvaluated(boolean isCorrect);
}
class QuizGameClient extends QuizGame implements QuizGameListener {
    private QuizGameServer server;

    public QuizGameClient(QuizGameServer server) {
        this.server = server;
        server.addListener(this);
    }

    @Override
    void startGame() {
        server.startGame();
    }

    @Override
    void askQuestion() {
        // The server will notify the client about the question
    }

    @Override
    void evaluateAnswer(String answer) {
        // The server will notify the client about the answer evaluation
    }

    @Override
    public void onQuestionAsked(String question) {
        System.out.println("Question: " + question);
        // Display the question to the client
    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        if (isCorrect) {
            System.out.println("Your answer is correct!");
        } else {
            System.out.println("Your answer is incorrect.");
        }
        // Display the result to the client
    }
}
public class Client {
    public static void main(String[] args) {
        QuizGameServer server = new QuizGameServer();
        QuizGameClient client = new QuizGameClient(server);
        // Start the game (com.amrita.jpl.cys21031.p2.Client-side)
        client.startGame();
        // Simulating user input for answer evaluation (com.amrita.jpl.cys21031.p2.Client-side)
        client.evaluateAnswer(" Tiger");
        client.evaluateAnswer("Mumbai");
        client.evaluateAnswer("Mahathama Gandhi");
    }
}