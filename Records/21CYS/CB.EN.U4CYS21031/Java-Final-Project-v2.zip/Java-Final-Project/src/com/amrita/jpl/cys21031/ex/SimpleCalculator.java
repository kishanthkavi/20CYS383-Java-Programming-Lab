package com.amrita.jpl.cys21031.ex;

import java.util.Scanner;

/**
 * @author Kishanth K
 * @version 0.5
 *
 * A class SimpleCalculator using Interface to do operations like Addition, Subtraction, Multiplication and Division.
 */

interface Calculator {
    double add(double num1, double num2);
    double subtract(double num1, double num2);
    double multiply(double num1, double num2);
    double divide(double num1, double num2);
}

class BasicCalculator implements Calculator {
    public double add(double num1, double num2) {
        return num1 + num2;
    }

    public double subtract(double num1, double num2) {
        return num1 - num2;
    }

    public double multiply(double num1, double num2) {
        return num1 * num2;
    }

    public double divide(double num1, double num2){
        return num1 / num2;
    }
}
 class BasicCalculatorQ{
    public static void main(String[] args) {
        BasicCalculator calculator = new BasicCalculator();
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        double num1 = input.nextDouble();

        System.out.print("Enter the second number: ");
        double num2 = input.nextDouble();

        System.out.print("Enter the operation (+, -, *, /): ");
        char operation = input.next().charAt(0);

        double result;
        switch (operation) {
            case '+':
                result = calculator.add(num1, num2);
                System.out.println("Result: " + result);
                break;
            case '-':
                result = calculator.subtract(num1, num2);
                System.out.println("Result: " + result);
                break;
            case '*':
                result = calculator.multiply(num1, num2);
                System.out.println("Result: " + result);
                break;
            case '/':
                if(num2 != 0) {
                    try {
                        result = calculator.divide(num1, num2);
                        System.out.println("Result: " + result);
                    } catch (ArithmeticException e) {
                        System.out.println("Cannot Divide");
                    }
                }
                else{
                    System.out.println("Cannot divide by zero");
                }
                break;
            default:
                System.out.println("Invalid operation!");
                break;
        }

        input.close();
    }
}
