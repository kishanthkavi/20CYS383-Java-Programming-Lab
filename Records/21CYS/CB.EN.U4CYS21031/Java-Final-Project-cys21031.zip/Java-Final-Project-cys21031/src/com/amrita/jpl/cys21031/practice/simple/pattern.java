package com.amrita.jpl.cys21031.practice.simple;

/**
 * @author Kishanth K
 * @version 0.5
 *
 * A Java program to print the following pattern
 */
public class pattern {
    public  static  void main(String[] args){
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * *  ===================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * *  ===================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * * ====================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("* * * * *  ===================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
    }
}