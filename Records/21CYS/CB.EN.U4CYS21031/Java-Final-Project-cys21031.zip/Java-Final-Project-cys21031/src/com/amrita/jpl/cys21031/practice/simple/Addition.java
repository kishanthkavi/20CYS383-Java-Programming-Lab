package com.amrita.jpl.cys21031.practice.simple;

/**
 * @author Kishanth K
 * @version 0.5
 *
 * A Basic Java program to print addition of 2 numbers
 */
class Addition {
    public static void main(String[] args) {
        int x=1;
        int y=3;
        int sum=x+y;
        System.out.println("Sum="+sum);
    }
}

